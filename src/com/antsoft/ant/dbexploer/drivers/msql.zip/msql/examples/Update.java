/* $Id: Update.java,v 2.1 1998/10/29 06:58:52 borg Exp $ */
import java.sql.*;

/**
 * Last modified $Date: 1998/10/29 06:58:52 $
 * @version $Revision: 2.1 $
 */
public class Update {
    public static void main(String args[]) {
	if( args.length != 2 ) {
	    System.err.println("Syntax: <java Update [number] [string]>");
	    return;
	}
	try {
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Connection con = DriverManager.getConnection(url, "borg", "");
	    Statement s = con.createStatement();
	    
	    s.executeUpdate("INSERT INTO test (test_id, test_val) " +
			    "VALUES(" + args[0] + ", '" + args[1] + "')");
	    System.out.println("Insert succeeded.");
	    con.close();
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
