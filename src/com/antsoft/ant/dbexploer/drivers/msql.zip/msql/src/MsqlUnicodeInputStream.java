/* $Id: MsqlUnicodeInputStream.java,v 2.0 1998/10/21 02:38:55 borg Exp $ */
/* Copyright (c) 1997 George Reese */
package com.imaginary.sql.msql;

import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;

/**
 * Last modified $Date: 1998/10/21 02:38:55 $
 * @version $Revision: 2.0 $
 * @author George Reese (borg@imaginary.com)
 */
public class MsqlUnicodeInputStream extends FilterInputStream {
    public MsqlUnicodeInputStream(byte[] data) {
	super(new ByteArrayInputStream(data));
    }

    public int read() throws IOException {
	int left = super.read();
	int right = super.read();

	return ((left<<8) + right);
    }
}
