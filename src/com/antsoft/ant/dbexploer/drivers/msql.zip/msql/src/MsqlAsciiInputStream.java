/* $Id: MsqlAsciiInputStream.java,v 2.0 1998/10/21 02:38:43 borg Exp $ */
/* Copyright (c) 1997 George Reese */
package com.imaginary.sql.msql;

import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;

/**
 * An MsqlAsciiInputStream is used for the JDBC ResultSet getAsciiStream()
 * method to represent an ascii stream from a query.<BR>
 * Last modified $Date: 1998/10/21 02:38:43 $
 * @version $Revision: 2.0 $
 * @author George Reese (borg@imaginary.com)
 */
public class MsqlAsciiInputStream extends FilterInputStream {
    /**
     * Constructs an MsqlAsciiInputStream.
     */
    public MsqlAsciiInputStream(byte[] data) {
	super(new ByteArrayInputStream(data));
    }
}
