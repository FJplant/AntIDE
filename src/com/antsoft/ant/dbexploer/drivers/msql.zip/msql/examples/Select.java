/* $Id: Select.java,v 2.3 1999/01/20 20:49:56 borg Exp $ */
import java.sql.*;
import java.util.*;

/**
 * Last modified $Date: 1999/01/20 20:49:56 $
 * @version $Revision: 2.3 $
 */
public class Select {
    public static void main(String argv[]) {
	try {
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Properties p = new Properties();
	    Connection con;
	    Statement stmt;
	    ResultSet rs;
	    
	    p.put("user", "borg");
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    con = DriverManager.getConnection(url, "borg", "");
	    stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
				       ResultSet.CONCUR_READ_ONLY);
	    rs = stmt.executeQuery("SELECT test_id, test_int, test_date, " +
				   "test_char, test_val " +
				   "FROM test ORDER BY test_id");
	    System.out.println("Got results:");
	    while( rs.next() ) {
		int i = rs.getInt(1);
		String s, comma = "";
		java.util.Date d;

		System.out.print("\tkey: " + i + "(");
		i = rs.getInt(2);
		if( !rs.wasNull() ) {
		    System.out.print("test_int=" + i);
		    comma = ",";
		}
		d = rs.getDate(3);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_date=" + d);
		    comma = ",";
		}
		s = rs.getString(4);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_char='" + s + "'");
		    comma = ",";
		}
		s = rs.getString(5);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_val='" + s + "'");
		}
		System.out.println(")");
	    }
	    System.out.println("And now, backwards:");
	    rs.last();
	    do {
		int i = rs.getInt(1);
		String s, comma = "";
		java.util.Date d;

		System.out.print("\tkey: " + i + "(");
		i = rs.getInt(2);
		if( !rs.wasNull() ) {
		    System.out.print("test_int=" + i);
		    comma = ",";
		}
		d = rs.getDate(3);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_date=" + d);
		    comma = ",";
		}
		s = rs.getString(4);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_char='" + s + "'");
		    comma = ",";
		}
		s = rs.getString(5);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_val='" + s + "'");
		}
		System.out.println(")");
	    } while( rs.previous() );
	    System.out.println("And now, row number 2:");
	    if( rs.absolute(2) ) {
		int i = rs.getInt(1);
		String s, comma = "";
		java.util.Date d;

		System.out.print("\tkey: " + i + "(");
		i = rs.getInt(2);
		if( !rs.wasNull() ) {
		    System.out.print("test_int=" + i);
		    comma = ",";
		}
		d = rs.getDate(3);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_date=" + d);
		    comma = ",";
		}
		s = rs.getString(4);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_char='" + s + "'");
		    comma = ",";
		}
		s = rs.getString(5);
		if( !rs.wasNull() ) {
		    System.out.print(comma + "test_val='" + s + "'");
		}
		System.out.println(")");
	    }		
	    con.close();
	    System.out.println("Done.");
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
  
