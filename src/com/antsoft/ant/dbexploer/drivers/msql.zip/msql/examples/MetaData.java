/* $Id: MetaData.java,v 2.2 1999/01/20 20:49:54 borg Exp $ */
import java.sql.*;
import java.util.*;

/**
 * Last modified $Date: 1999/01/20 20:49:54 $
 * @version $Revision: 2.2 $
 */
public class MetaData {
    public static void main(String argv[]) {
	try {
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Properties p = new Properties();
	    DatabaseMetaData meta;
	    Connection con;
	    ResultSet rs;
	    
	    p.put("user", "borg");
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    con = DriverManager.getConnection(url, "borg", "");
	    meta = con.getMetaData();
	    rs = meta.getTables(null, null, null, null);
	    while( rs.next() ) {
		String table = rs.getString("TABLE_NAME");
		ResultSet cols, keys;
		
		System.out.println("Table: " + rs.getString("TABLE_NAME"));
		System.out.print("\tColumns: (");
		cols = meta.getColumns(null, null, table, null);
		if( cols.next() ) {
		    System.out.print(cols.getString("NAME"));
		    while( cols.next() ) {
			System.out.print("," + cols.getString("NAME"));
		    }
		}
		System.out.println(")");
		cols.close();
		keys = meta.getPrimaryKeys(null, null, table);
		keys.next(); // first row is index type
		if( keys.next() ) {
		    System.out.print("\tKeys: (" + keys.getString("DATA"));
		    while( keys.next() ) {
			System.out.print("," + keys.getString("DATA"));
		    }
		    System.out.println(")");
		}
		keys.close();
	    }
	    con.close();
	    System.out.println("Done.");
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
