# $Id: examples.sql,v 2.1 1999/01/20 20:49:57 borg Exp $
# Last modified $Date: 1999/01/20 20:49:57 $
# Version $Revision: 2.1 $
#
# Execute this command in UNIX (where DATABASE is your database name):
#       msql DATABASE < examples.sql

DROP TABLE test\g

CREATE TABLE test(
       test_id		INT	NOT NULL,
       test_int		INT,
       test_date	DATE,
       test_char	CHAR(24),	
       test_val		TEXT(255)	
)\g

CREATE UNIQUE INDEX test_idx ON test(test_id)\g

DROP TABLE utest\g

CREATE TABLE utest(
       uid	INT		NOT NULL,
       uval	TEXT(255)
)\g

CREATE UNIQUE INDEX uid_idx ON utest(uid)\g
