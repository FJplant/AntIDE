/* $Id: Exec.java,v 2.1 1998/10/29 06:58:49 borg Exp $ */
import java.sql.*;

/**
 * Last modified $Date: 1998/10/29 06:58:49 $
 * @version $Revision: 2.1 $
 */
public class Exec {
    public static void main(String args[]) {
	String sql = "";
      
	for(int i=0; i<args.length; i++) {
	    sql = sql + args[i];
	    if( i < args.length - 1 ) {
		sql = sql + " ";
	    }
	}
	System.out.println("Executing: " + sql);
	try {
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Connection con = DriverManager.getConnection(url, "borg", "");
	    Statement s = con.createStatement();   
	    
	    if( s.execute(sql) ) {
		ResultSet r = s.getResultSet();
		ResultSetMetaData meta = r.getMetaData();
		int cols = meta.getColumnCount();
		int rownum = 0;
		
		while( r.next() ) {
		    rownum++;
		    System.out.println("Row: " + rownum);
		    for(int i=0; i<cols; i++) {
			System.out.print(meta.getColumnLabel(i+1) + ": "
					 + r.getObject(i+1) +  ", ");
		    }
		    System.out.println("");
		}
	    }
	    else {
		System.out.println(s.getUpdateCount() + " rows affected.");
	    }
	    con.close();
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
    
