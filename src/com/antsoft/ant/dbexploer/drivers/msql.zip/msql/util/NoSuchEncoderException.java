/* $Id: NoSuchEncoderException.java,v 1.1.1.1 1999/01/25 23:49:00 borg Exp $ */
/* Copyright � 1999 George Reese, All Rights Reserved */
package com.imaginary.util;

public class NoSuchEncoderException extends Exception {
    private int type = 0;

    public NoSuchEncoderException(int t) {
	super("Unable to load encoder for type: " + t);
	type = t;
    }
}
