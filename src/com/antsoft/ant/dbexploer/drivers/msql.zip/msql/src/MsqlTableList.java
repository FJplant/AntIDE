/* $Id: MsqlTableList.java,v 2.2 1999/03/03 03:27:14 borg Exp $ */
/* Copyright � 1998 George Reese, All Rights Reserved */
package com.imaginary.sql.msql;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * This class represents a ResultSet containing table information about
 * the tables in an mSQL database.
 * <BR>
 * Last modified: $Date: 1999/03/03 03:27:14 $
 * @version $Revision: 2.2 $
 * @author George Reese (borg@imaginary.com)
 */
public class MsqlTableList extends MsqlResultSet {
    // Flags whether or not the load is complete
    private   boolean           complete         = false;
    // The connection that owns this table list
    private   MsqlConnection    connection       = null;
    // The current row number of the result set
    private   int               rowNumber        = -1;
    // The data for the current row
    private   byte[][]          currentRow       = null;
    // The meta data results
    private   MsqlResultSet     fieldInfo        = null;
    // The data for the last column read
    protected byte[]            lastColumn       = null;
    // The meta data for this result set
    private   ResultSetMetaData metaData         = null;
    // The name pattern to search on
    private   String            namePattern      = null;
    // Any exception that may have occurred during data read
    private   MsqlException     readException    = null;
    // The rows in the result set
    private   ArrayList         rows             = new ArrayList();

    MsqlTableList(MsqlConnection conn, String np, int ll) throws SQLException {
	super(null, ll);
	connection = conn;
	namePattern = np;
	getRows();
    }

    /**
     * This only throws an error since absolute movement is illegal with
     * this result set.
     * @param row the row to move to
     * @return nothing at all
     * @exception java.sql.SQLException this is always thrown
     */
    public boolean absolute(int row) throws SQLException {
	throw new MsqlException("This result set is TYPE_FORWARD_ONLY.");
    }
    
    /**
     * Closes the result set.
     * @exception java.sql.SQLException thrown for errors on closing
     */
    public void close() throws SQLException {
	synchronized( rows ) {
	    while( !complete ) {
		try { rows.wait(1500); }
		catch( InterruptedException e ) {
		}
	    }
	    if( fieldInfo != null ) {
		fieldInfo.close();
	    }
	}
    }

    /**
     * Marks the load as completed.
     */
    public void complete() {
	connection.release();
	synchronized( rows ) {
	    complete = true;
	}
    }
    
    /**
     * @param name the name of the desired column
     * @return the column number for the specified column name
     * @exception java.sql.SQLException thrown on a read error
     */
    public int findColumn(String name) throws SQLException {
	if( name.equals("TABLE_CAT") ) {
	    return 1;
	}
	else if( name.equals("TABLE_SCHEM") ) {
	    return 2;
	}
	else if( name.equals("TABLE_NAME") ) {
	    return 3;
	}
	else if( name.equals("TABLE_TYPE") ) {
	    return 4;
	}
	else if( name.equals("REMARKS") ) {
	    return 5;
	}
	else {
	    throw new SQLException("Invalid column name: " + name);
	}
    }

    /**
     * @param column the column number for the desired column
     * @return an ASCII input stream for the desired column
     * @exception java.sql.SQLException thrown when the column cannot be read
     */
    public InputStream getAsciiStream(int column) throws SQLException {
	getColumn(column);
	return new MsqlAsciiInputStream(lastColumn);
    }

    /**
     * @param column the column number for the desired column
     * @return the binary input stream for the desired column
     * @exception java.sql.SQLException thrown when the column cannot be read
     */
    public InputStream getBinaryStream(int column) throws SQLException {
	getColumn(column);
	return new ByteArrayInputStream(lastColumn);
    }

    /**
     * @param column the number for the desired column
     * @return the specified column as a boolean
     * @exception java.sql.SQLException an error occurred in reading the data
     */
    public boolean getBoolean(int column) throws SQLException {
	getColumn(column);
	if( wasNull() ) {
	    return false;
	}
	if( lastColumn.length == 0 ) {
	    return false;
	}
	else if( lastColumn[0] == '0' || lastColumn[0] == '\0' ) {
	    return false;
	}
	else {
	    return true;
	}
    }

    /**
     * @param column the number for the desired column
     * @return the specified column as a byte
     * @exception java.sql.SQLException an error occurred in reading the data
     */
    public byte getByte(int column) throws SQLException {
	getColumn(column);
	if( wasNull() ) {
	    return (byte)0;
	}
	else {
	    return lastColumn[0];
	}
    }

    /**
     * @param column the number for the desired column
     * @return the specified column as a byte array
     * @exception java.sql.SQLException an error occurred in reading the data
     */
    public byte[] getBytes(int column) throws SQLException {
	getColumn(column);
	return lastColumn;
    }

    /**
     * Fetches the specified column and sets the value for lastColumn.
     * @param column the column to fetch
     * @exception java.sql.SQLException an error occurred fetching the column
     */
    protected void getColumn(int column) throws SQLException {
	try {
	    lastColumn = currentRow[column-1];
	}
	catch( Exception e ) {
	    if( currentRow == null ) {
		throw new MsqlException("-1:Result set positioned before " +
					"first row.");
	    }
	    throw new MsqlException(e);
	}
    }

    /**
     * @return CONCUR_READ_ONLY
     * @exception java.sql.SQLException this is never thrown
     */
    public int getConcurrency() throws SQLException {
	return ResultSet.CONCUR_READ_ONLY;
    }

    /**
     * @return the meta data for this table list
     * @exception java.sql.SQLException an error occurred reading the meta
     * data
     */
    public ResultSetMetaData getMetaData() throws SQLException {
	if( metaData != null ) {
	    return metaData;
	}
	synchronized( rows ) {
	    while( fieldInfo == null ) {
		try { rows.wait(1500); }
	        catch( InterruptedException e ) { }
	    }
	    metaData = new MsqlResultSetMetaData(fieldInfo);
	}
	return metaData;
    }

    /**
     * @return the current row number
     * @exception java.sql.SQLException this is never thrown
     */
    public int getRow() throws SQLException {
	return (rowNumber+1);
    }
    
    /**
     * @return the data for the specified row
     * @exception java.sql.SQLException an attempt was made to read an invalid
     * row
     */
    private byte[][] getRow(int row) throws SQLException {
	if( readException != null ) {
	    throw readException;
	}
	if( row < 0 ) {
	    throw new SQLException("Attempt to access a non-existent row.");
	}
	synchronized( rows ) {
	    while( rows.size() <= row ) {
		if( complete ) {
		    throw new SQLException("Attempt to access a " +
					   "non-existent row.");
		}
		else {
		    try { rows.wait(1500); }
		    catch( InterruptedException e ) { }
		}
	    }
	}
	return (byte[][])rows.get(row);
    }

    /**
     * Loads the results.
     */
    private void getRows() {
	while( true ) {
	    byte[] data;
	    String tmp;

	    try {
		data = connection.getInputStream().read();
	    }
	    catch( IOException e ) {
		complete();
		readException = new MsqlException(e);
		return;
	    }
	    try {
		tmp = new String(data, "8859_1");
	    }
	    catch( UnsupportedEncodingException e ) {
		complete();
		readException = new MsqlException(e);
		return;
	    }
	    if( tmp.startsWith("-1:") ) {
		complete();
		readException = new MsqlException(tmp);
		return;
	    }
	    else if( tmp.startsWith("-100") ) {
		break;
	    }
	    else {
		try {
		    readRow(data);
		}
		catch( SQLException e ) {
		    complete();
		    readException = new MsqlException(e);
		    return;
		}
	    }
	}
	try {
	    fieldInfo = new MsqlQueryData(null, 6, this, log.getLevel());
	    complete();
	}
	catch( SQLException e ) {
	    readException = new MsqlException(e);
	    complete();
	    fieldInfo = null;
	}
    }

    /**
     * @param column the desired column
     * @return the column as a String
     * @exception java.sql.SQLException an error occurred reading the column
     */
    public String getString(int column) throws SQLException {
	getColumn(column);
	if( wasNull() ) {
	    return null;
	}
	else {
	    try {
		return new String(lastColumn, "8859_1");
	    }
	    catch( UnsupportedEncodingException e ) {
		throw new MsqlException(e);
	    }
	}
    }

    /**
     * @return TYPE_FORWARD_ONLY
     * @exception java.sql.SQLException this is never thrown
     */
    public int getType() throws SQLException {
	return ResultSet.TYPE_FORWARD_ONLY;
    }
    
    /**
     * @param column the desired column number
     * @return the specified column as an input stream
     * @exception java.sql.SQLException a database error occurred
     * @deprecated
     */
    public InputStream getUnicodeStream(int column) throws SQLException {
	getColumn(column);
	return new MsqlUnicodeInputStream(lastColumn);
    }

    /**
     * This is an expensive operation and should be avoided.
     * @return true if the current row is the last row
     * @exception java.sql.SQLException this is never thrown
     */
    public boolean isLast() throws SQLException {
	synchronized( rows ) {
	    while( !complete ) {
		try { rows.wait(1500); }
		catch( InterruptedException e ) { }
	    }
	}
	if( rowNumber == (rows.size()-1) ) {
	    return true;
	}
	else {
	    return false;
	}
    }
    
    /**
     * Moves to the next row of data for processing.  If there are no
     * more rows to be processed, then it will return false.
     * @return true if there are results to be processed, false otherwise
     * @exception java.sql.SQLException thrown if a read error occurs
     */
    public boolean next() throws SQLException {
	rowNumber++;
	try {
	    currentRow = getRow(rowNumber);
	}
	catch( SQLException e ) {
	    return false;
	}
	return true;
    }

    /**
     * Moves to the next row of data for processing.  If there are no
     * more rows to be processed, then it will return false.
     * @return true if there are results to be processed, false otherwise
     * @exception java.sql.SQLException thrown if a read error occurs
     */
    public boolean previous() throws SQLException {
	throw new MsqlException("ResultSet is forward-only.");
    }

    /**
     * Reads a single row of data.
     */
    private void readRow(byte[] data) throws SQLException {
	byte[][] cols = new byte[5][];
	String ascii;

	try {
	    ascii = new String(data, "8859_1");
	}
	catch( UnsupportedEncodingException e ) {
	    throw new MsqlException(e);
	}
	for(int i=0; i<5; i++) {
	    if( i < 2 ) {
		cols[i] = null;
	    }
	    else if( i == 2 ) {
		// we can get away with this since
		// ascii arabics == unicode arabics
		int colon = ascii.indexOf(':');
		byte[] column;
		int size;

		try {
		    size = Integer.parseInt(ascii.substring(0, colon));
		}
		catch( NumberFormatException e ) {
		    throw new SQLException("Invalid row data format from " +
					   "mSQL.");
		}
		if( size == -2 ) {
		    column = null;
		    size = 0;
		}
		else {
		    String tmp = ascii.substring(colon+1, colon+size+1);
		    
		    try {
			column = tmp.getBytes("8859_1");
		    }
		    catch( UnsupportedEncodingException e ) {
			throw new MsqlException(e);
		    }
		}
		cols[i] = column;
		ascii = ascii.substring(colon+size+1);
	    }
	    else if( i == 3 ) {
		byte[] cv = { (byte)'T', (byte)'A', (byte)'B', (byte)'L',
			      (byte)'E' };

		cols[i] = cv;
	    }
	    else {
		byte[] cv = { (byte)'N', (byte)'o' };

		cols[i] = cv;
	    }
	}
	synchronized( rows ) {
	    rows.add(cols);
	    rows.notifyAll();
	}
    }

    /**
     * This only throws an error since relative movement is illegal with
     * this result set.
     * @param count the number of rows to move
     * @return nothing at all
     * @exception java.sql.SQLException this is always thrown
     */
    public boolean relative(int count) throws SQLException {
	throw new MsqlException("This result set is TYPE_FORWARD_ONLY.");
    }
    
    /**
     * @return true if the last value read was null
     * @exception java.sql.SQLException never thrown
     */
    public synchronized boolean wasNull() throws SQLException {
	if( lastColumn == null ) {
	    return true;
	}
	else {
	    return false;
	}
    }
}
