/* $Id$ */
/* Copyright � 1999 George Reese, All Rights Reserved */
package com.imaginary.util;

/**
 * Provides a generic interface for data encoding operations. This
 * class is agnostic about the type of encoding going on. It simply
 * prescribes two methods for taking a string or an array of bytes and
 * translating that data into some other form.
 * <P>
 * Accessing encoders should be done through this class in the following
 * manner:
 * <PRE>
 * Encoder encoder = Encoder.getInstance(Encoder.BASE64);
 * </PRE>
 * <BR>
 * Last modified $Date$
 * @version $Revision$
 * @author George Reese (borg@imaginary.com)
 */
public abstract class Encoder {
    /**
     * The encoder for BASE64 encoding.
     */
    static public final int BASE64 = 1;

    /**
     * Provides an instance of the specified encoder.
     
     */
    static public Encoder getInstance(int type)
    throws NoSuchEncoderException {
	switch( type ) {
	case Encoder.BASE64:
	    {
		return new Base64Encoder();
	    }
	default:
	    {
		throw new NoSuchEncoderException(type);
	    }
	}
    }

    public abstract byte[] decode(byte[] encoded);

    public abstract byte[] decode(String encoded);
    
    public abstract byte[] encode(byte[] decoded);

    public abstract byte[] encode(String decoded);
}
