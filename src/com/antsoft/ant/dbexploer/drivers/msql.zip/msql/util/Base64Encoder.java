/* $Id: Base64Encoder.java,v 1.1.1.1 1999/01/25 23:49:00 borg Exp $ */
/* Copyright � 1999 George Reese, All Rights Reserved */
package com.imaginary.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * Provides BASE64 encoding and decoding for binary data. This class currently
 * uses the <CODE>sun.misc.BASE64Encoder</CODE> and
 * <CODE>sun.misc.BASE64Decoder</CODE> classes. The point of this class
 * is first of all to work with a generic encoding/decoding API and
 * second of all provide a level of indirection from the Sun classes
 * in the event they stop supporting those classes.
 * <P>
 * BASE64 encoding is a way to save binary data in ASCII strings. To make
 * use of BASE64 encoding, execute the following code:
 * <PRE>
 * Encoder encoder = Encoder.getInstance(Encoder.BASE64);
 * String ascii = new String(encoder.encode(binary), "8859_1");
 * </PRE>
 * <BR>
 * Last modified $Date$
 * @version $Revision$
 * @author George Reese (borg@imaginary.com)
 */
public class Base64Encoder extends Encoder {
    /**
     * Constructs a new encoder.
     */
    Base64Encoder() {
	super();
    }

    /**
     * Decodes a byte array representing an ASCII string into its original,
     * binary format.
     * @param encoded a byte array of BASE64 encoded ASCII data
     * @return a byte array of decoded binary data
     */
    public byte[] decode(byte[] encoded) {
	// Base64 works in the ASCII realm, so we can use an ASCII encoding
	try {
	    return decode(new String(encoded, "8859_1"));
	}
	catch( UnsupportedEncodingException bullshit ) {
	    // this should not be able to happen
	    return null;
	}
    }

    /**
     * Decodes an ASCII string into its original, binary format.
     * @param encoded an ASCII string of BASE64 encoded data
     * @return a byte array of decoded binary data
     */
    public byte[] decode(String encoded) {
	try {
	    BASE64Decoder enc = new BASE64Decoder();
	    
	    return enc.decodeBuffer(encoded);
	}
	catch( IOException bullshit ) {
	    return null;
	}
    }

    /**
     * Encodes raw binary data into an ASCII format.
     * @param decoded the raw binary data to be encoded
     * @return a byte array representing an ASCII string
     */
    public byte[] encode(byte[] decoded) {
	try {
	    BASE64Encoder enc = new BASE64Encoder();
	    String tmp = enc.encode(decoded);
	    
	    return tmp.getBytes("8859_1");
	}
	catch( UnsupportedEncodingException bullshit ) {
	    return null;
	}
    }

    /**
     * Encodes a Unicode string into an ASCII format.  You will likely
     * never want to use this method.   Because BASE63 encoding
     * is for encoding binary data into an ASCII format,
     * this method really exists for compatibility
     * with the <CODE>Encoder</CODE> interface.
     * @param decoded a Unicode string
     * @return a byte array representing an ASCII string
     */
    public byte[] encode(String decoded) {
	return encode(decoded.getBytes());
    }
}
