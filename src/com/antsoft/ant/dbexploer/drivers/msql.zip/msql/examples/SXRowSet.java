/* $Id$ */
import com.imaginary.sql.ImaginaryRowSet;
import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.*;

/**
 * Last modified $Date$
 * @version $Revision$
 */
public class SXRowSet {
    public static void main(String args[]) {
	if( args.length > 0 && args[0].equals("install") ) {
	    try {
		registerDataSource();
		System.out.println("Data source 'jdbc/test' installed.");
	    }
	    catch( Exception e ) {
		e.printStackTrace();
		System.out.println("Install failed.");
	    }
	    return;
	}	    
	if( args.length != 1 ) {
	    System.err.println("You should specify a test_id number.");
	    System.exit(-1);
	    return;
	}
	System.setProperty(Context.INITIAL_CONTEXT_FACTORY,
			   "com.sun.jndi.fscontext.RefFSContextFactory");
	try {
	    ImaginaryRowSet rs = new ImaginaryRowSet();

	    rs.setDataSourceName("/tmp/jdbc/test");
	    rs.setUsername("borg");
	    rs.setPassword("");
	    rs.setCommand("SELECT test_val from test WHERE test_id = ?");
	    rs.setInt(1, Integer.parseInt(args[0]));
	    rs.execute();
	    while( rs.next() ) {
		String str = rs.getString(1);

		if( rs.wasNull() ) {
		    System.out.println("The test_val column for test_id " +
				       args[0] + " was NULL.");
		}
		else {
		    System.out.println("test_val= '" + str + "'");
		}
	    }
	    rs.close();
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
    
    /**
     * This method is separated from the rest of the example since you
     * normally would NOT register a JDBC driver in your code.  It would
     * likely be configered into your naming and directory service
     * using some GUI.
     */
    static public void registerDataSource() throws Exception {
	com.imaginary.sql.msql.MsqlDataSource ds;
	Context ctx;
	
	Hashtable env = new Hashtable();
	env.put(Context.INITIAL_CONTEXT_FACTORY,
		"com.sun.jndi.fscontext.RefFSContextFactory");
	ctx = new InitialContext(env);
	ds = new com.imaginary.sql.msql.MsqlDataSource();
	ds.setServerName("carthage.imaginary.com");
	ds.setDatabaseName("test");
	ctx.bind("/tmp/jdbc/test", ds);
	ctx.close();
    }
}
  
