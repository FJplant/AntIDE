/* $Id: Prepared.java,v 2.2 1999/01/20 20:49:54 borg Exp $ */
import java.sql.*;
import java.util.*;

/**
 * Last modified $Date: 1999/01/20 20:49:54 $
 * @version $Revision: 2.2 $
 */
public class Prepared {
    public static void main(String args[]) {
	if( args.length != 1 ) {
	    System.err.println("You should specify a test_id number.");
	    System.exit(-1);
	    return;
	}
	try {
	    String url = "jdbc:msql://carthage.imaginary.com:1114/test";
	    Properties p = new Properties();
	    PreparedStatement stmt;
	    Connection con;
	    ResultSet rs;
	    
	    p.put("user", "borg");
	    Class.forName("com.imaginary.sql.msql.MsqlDriver");
	    con = DriverManager.getConnection(url, "borg", "");
	    stmt = con.prepareStatement("SELECT test_val from test " +
					"WHERE test_id = ?");
	    stmt.setInt(1, Integer.parseInt(args[0]));
	    rs = stmt.executeQuery();
	    while(rs.next()) {
		String str = rs.getString(1);

		if( rs.wasNull() ) {
		    System.out.println("The test_val column for test_id " +
				       args[0] + " was NULL.");
		}
		else {
		    System.out.println("test_val= '" + str + "'");
		}
	    }
	    con.close();
	}
	catch( Exception e ) {
	    e.printStackTrace();
	}
    }
}
  
