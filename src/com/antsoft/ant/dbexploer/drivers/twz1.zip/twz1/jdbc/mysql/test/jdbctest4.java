
import twz1.jdbc.mysql.*;
import java.sql.*;
import java.lang.String;
import java.util.Random;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintWriter;
public class jdbctest4
{
int mutwait;

public static void main(String[] arg)
    { new jdbctest4(); }

jdbctest4()
    {
    int xrc;
    String ws1, ws2, ws3, ws4, ws5;
    boolean brc;

//-------------------------------------------------------------

    header("Loading Driver");

    try { Class.forName("twz1.jdbc.mysql.jdbcMysqlDriver"); }
    catch(Exception e){System.out.println(e);}


//-------------------------------------------------------------

    header("Displaying default properties");

    String t[] = jdbcMysqlBase.getDefaultNames();
    for(int i = 0; i < t.length; i++)
        {
        System.out.println(t[i] + "  " + 
               jdbcMysqlBase.getDefault(t[i]));
        }

//------------------------------------------------------------ 

    header("The following connex will succeed");

    Connection cx = null;
    String url = "jdbc:z1MySQL:";
    try {
        cx = DriverManager.getConnection(url);
        }
    catch(SQLException se){System.out.println(se);} 
  
//------------------------------------------------------------
  
    header("Setting catalog to jdbctest");

    if(cx instanceof twz1.jdbc.mysql.jdbcMysqlConnex)
              System.out.println("cx is instance");

    try {
        cx.setCatalog("jdbctest");
        String s = cx.getCatalog();
        System.out.println("Catalog is now " + s);
        }
    catch(Exception e) { System.out.println(e); }
 
//------------------------------------------------------------ 
     header("test multiple query");
     try{ 
        boolean mc = jdbcMysqlBase.isMultipleQuery((jdbcMysqlConnex) cx);
        System.out.println("Is connection multiple query: " + mc);
        }
    catch(Exception e) { System.out.println(e); }
    
//------------------------------------------------------------ 

    header("Creating statement");

    Statement st = null;

    try {
        st = cx.createStatement();
        }
    catch(Exception e) { e.printStackTrace(); }

//------------------------------------------------------------

    header("Creating table");

    try {
        xrc = st.executeUpdate( "create table books (rownum int not null"
                              +   " auto_increment, bname text not null,"
                              +   " author text not null, pubdate int,"
                              +   " isbn char(20) not null, price decimal(6,2),"
                              +   " primary key(isbn), index(rownum))" ); 

       if(st instanceof twz1.jdbc.mysql.jdbcMysqlStmt)
              System.out.println("st is instance of "+st.getClass());
        System.out.println("Returns " + xrc);
        }
    catch(Exception e) { e.printStackTrace(); }


    PreparedStatement ps = null;
    try {
        ps  =  cx.prepareStatement("Insert into books values(0, ?, ?, ?, ?, ?)");
        }
    catch(Exception e) { e.printStackTrace(); }
  

    header("Waiting for input");
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);
    try {String x = br.readLine();}
    catch(IOException ioe){}
    


//------------------------------------------------------------

    header("Loading table via inserts");

    try {
        ps.setString(1, "PC System Programming");
        ps.setString(2, "Tischer");
        ps.setString(3, "1989");
        ps.setString(4, "Abacus");
        ps.setFloat(5, (float)59.95);
        ps.executeUpdate();
        }
    catch(Exception e) { e.printStackTrace(); }


    try {
        xrc = st.executeUpdate( "insert into books values(0, 'Essential System Administration', 'Frisch', 1993, '0-937175-80-3', 29.95)");
        System.out.println("Returns " + xrc);
        xrc = st.executeUpdate( "insert into books values(0, 'C, the Complete Reference',  'Schildt', 1987, '0-07-881263-1', 24.95)");
        System.out.println("Returns " + xrc);
        xrc = st.executeUpdate( "insert into books values(0, 'Teach Yourself C++',  'Stevens', 1993, '1-55828-250-5', 29.95)");
        System.out.println("Returns " + xrc);
        xrc = st.executeUpdate( "insert into books values(0, 'Operating Systems, Design and Implementation',  'Tanenbaum', 1987, '0-13-637406-9', 59.95)");
        System.out.println("Returns " + xrc);
        }
    catch(Exception e) { e.printStackTrace(); }

    try { ps = cx.prepareStatement("select * from books"); }
    catch(Exception e){ e.printStackTrace(); }

    header("Waiting for input");
    try {String x = br.readLine();}
    catch(IOException ioe){}
    
    try {
        ps.execute();
        ResultSet rs = ps.getResultSet();
	while(rs.next())
	  {
          System.out.println(rs.getString(1) + " " + rs.getString(2));
          }
        }
    catch(Exception e){e.printStackTrace(); }


//---------------------------------------------------------------

    header("closing statements");

    try { st.execute("drop table books"); }
    catch(Exception e){ e.printStackTrace(); }
    System.out.println("dropped books");
    
    try { st.close(); }
    catch(Exception e) { e.printStackTrace(); } 

    header("closing connection");

    try { cx.close(); }
    catch(SQLException se){System.out.println(se);}
      
    }

//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------

synchronized void waitFor(int cmd, int howmany)
    {
    if(cmd == 0)
        {
        mutwait += howmany;
        while(mutwait > 0) 
            {
            System.out.println("waitloop " + mutwait);
            try {
                wait();
                } 
            catch(InterruptedException e ) {}
            }
        }
    else{
        mutwait--;
        notify();
        System.out.println("wait notify : " + mutwait);
        }
    }

void header(String h)
    {
    String bl = "-----------------------------------";
    String sl = "                                   ";
    bl = new String("+" + bl + bl + "+");
    System.out.println("\n");
    System.out.println(bl);
    String rl = h;
    String tl;
    int i, j, k;
    while(rl != null)
        {
        if(rl.length() > 60)
            {
            tl = rl.substring(0, 60);
            rl = rl.substring(60);
            }
        else { tl = rl; rl = null; }
        k = ( 71 - tl.length() ) / 2;
        tl = new String(sl.substring(0, k) + tl + sl.substring(0, k));
        while(tl.length() > 70) tl = tl.substring(1);
        tl = new String("|" + tl + "|");
        System.out.println(tl);
        }
    System.out.println(bl);
    System.out.println("");
    }
    
/** Thanks to Steve Baker, ssbaker@primenet.com for the following
*** code to test a recursive call.
**/
void disptree(Connection con, int Key)
    {

    String query = "SELECT keyx, namex FROM nodes " +
			   "WHERE loc = " + Key;
    try {

        Statement stmt = con.createStatement();      
        ResultSet rs = stmt.executeQuery(query);
        while(rs.next()) 
            {
            System.out.println("<"+rs.getString("namex")+">");
	    disptree(con, rs.getInt("keyx"));
            }
        rs.close(); 
        stmt.close();      
        }
    catch( Exception e ) 
        {
        System.out.println(e.getMessage());
        e.printStackTrace();
        }
    }
}
   
class jdbctest1muts implements Runnable
{
jdbctest1 jt;
ResultSet rs1, rs2;
int num;
Thread myThread;
static long rseed;
static Random mRand;
jdbctest1muts(jdbctest1 j, int n, ResultSet r1, ResultSet r2)
    {
    this.jt = j;
    this.num = n;
    this.rs1 = r1;
    this.rs2 = r2;
    if(num ==  1)
        {
        rseed = 123456789L;
        mRand = new Random(rseed);
        }
    Thread myThread = new Thread(this);
    myThread.start();
    System.out.println("Thread " + num + " started.");
    }

public void run()
    {
    System.out.println("Thread " + num + " running.");
    String s = "crap";
    int t;
    for(int i = 0; i < 100; i++)
        {
        try { s = rs1.getString("bname"); }
        catch(Exception e) { s = e.getMessage(); }
        System.out.println(num + " " + i + " rs1 " + s); 
        t = mRand.nextInt() % 300; if(t<0)t*= -1; t++;
        try{myThread.sleep(t);} catch(InterruptedException ie){}
        try { s = rs2.getString("bname"); }
        catch(Exception e) { s = e.getMessage(); }
        System.out.println(num + " " + i + " rs2 " + s); 
        t = mRand.nextInt() % 300; if(t<0)t*= -1; t++;
        try{myThread.sleep(t);} catch(InterruptedException ie){}
        }
    jt.waitFor(1, 0);
    }


}
