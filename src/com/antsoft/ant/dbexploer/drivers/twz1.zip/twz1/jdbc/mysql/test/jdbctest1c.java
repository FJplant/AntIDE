
import twz1.jdbc.mysql.*;
import java.sql.*;
import java.lang.String;
import java.util.Random;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintWriter;
public class jdbctest1c
{
int mutwait;

public static void main(String[] arg)
    {
    new jdbctest1c();
    }

jdbctest1c()
    {
    int xrc;
    String url;
    boolean brc;
    Connection cx;

//-------------------------------------------------------------

    header("Loading Driver");

    try {
        Class.forName("twz1.jdbc.mysql.jdbcMysqlDriver");
        }
    catch(Exception e){System.out.println(e);}



    header("The following connex will succeed");

    cx = null;
    url = "jdbc:z1MySQL://localhost/stuff?maxField=4000000";
    try {
        cx = DriverManager.getConnection(url);
        }
    catch(SQLException se){System.out.println(se);} 
  
//------------------------------------------------------------
  
    header("Setting catalog to jdbctest");

    try {
        cx.setCatalog("jdbctest");
        String s = cx.getCatalog();
        System.out.println("Catalog is now " + s);
        }
    catch(Exception e) { System.out.println(e); }
 
    header("trying Big bags");
    try {
        Statement nb = cx.createStatement();
        String ct = "create table bigone (keyx int not null auto_increment," 
                   + " namex text,  stuff mediumblob,"
                   + " primary key(keyx))";
        nb.execute(ct);
        }
    catch(Exception e) { System.out.println(e); }
        
    try {
        String s = "insert into bigone values(0, ?, ?)";
        PreparedStatement ps = cx.prepareStatement(s);
        ps.setString(1, "jdbctestbinary1");
        FileInputStream fi = new FileInputStream("./jdbctestbinary1");
        ps.setBinaryStream(2, fi, ps.getMaxFieldSize());
        ps.execute();
        }
    catch(Exception e) { e.printStackTrace(); }



//---------------------------------------------------------------

    header("closing connection");

    try { cx.close(); }
    catch(SQLException se){System.out.println(se);}
      
    }
    
//---------------------------------------------------------------
//---------------------------------------------------------------

void header(String h)
    {
    String bl = "-----------------------------------";
    String sl = "                                   ";
    bl = new String("+" + bl + bl + "+");
    System.out.println("\n");
    System.out.println(bl);
    String rl = h;
    String tl;
    int i, j, k;
    while(rl != null)
        {
        if(rl.length() > 60)
            {
            tl = rl.substring(0, 60);
            rl = rl.substring(60);
            }
        else { tl = rl; rl = null; }
        k = ( 71 - tl.length() ) / 2;
        tl = new String(sl.substring(0, k) + tl + sl.substring(0, k));
        while(tl.length() > 70) tl = tl.substring(1);
        tl = new String("|" + tl + "|");
        System.out.println(tl);
        }
    System.out.println(bl);
    System.out.println("");
    }
    
}
