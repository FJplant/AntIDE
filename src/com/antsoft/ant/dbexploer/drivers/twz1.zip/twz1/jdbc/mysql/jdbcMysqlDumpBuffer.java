/**
*** Program jdbcMysqlDumpBuffer.java
***    in product twz1jdbcForMysql, 
***    Copyright 1997, 1998 by Terrence W. Zellers.
***   
***  All rights explicitly reserved.
***
***  See file "LICENSE" in this package for conditions of use.
**/

package twz1.jdbc.mysql;
import java.util.Vector;

/** This is just a classy way of doing a vector. */
final class jdbcMysqlDumpBuffer
{
Vector dumpBuffer;

public jdbcMysqlDumpBuffer()
    {
    this.dumpBuffer = new Vector();
    }

public void put(String s)
   {
   dumpBuffer.addElement(s);
   }

public String get()
   {
   String s;
   if(dumpBuffer.size() > 0) 
       {
       s = (String) dumpBuffer.elementAt(0);
       dumpBuffer.removeElementAt(0);
       }
   else s = null;
   return s;
   }
}
      
 

