
import java.sql.*;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintWriter;

public class GetBigOne
{

public static void main(String[] arg)
    {
    new GetBigOne(arg[0]);
    }

GetBigOne(String fname)
    {
    int xrc;
    String url;
    boolean brc;
    Connection cx;

    try {
        Class.forName("twz1.jdbc.mysql.jdbcMysqlDriver");
        }
    catch(Exception e){System.out.println(e);}

    cx = null;

    url = "jdbc:z1MySQL://localhost/jdbctest?user=zellert";
    try {cx = DriverManager.getConnection(url);    }
    catch(Exception se){System.out.println(se);} 
  
    try {
        Statement st = cx.createStatement();
        String q = "select stuff from bigone where namex like '"
                 + fname + "'";
        ResultSet rs = st.executeQuery(q);
        rs.next();
        byte[] b = rs.getBytes(1);
        rs.close();
        st.close();
        q  = "Content-Type: image/jpeg \r\n";
        q  += "Content-transfer-encoding: BINARY ";
        q  += String.valueOf(b.length);
        q  += "\r\n\r\n";
        System.out.print(q);
        System.out.write(b);
        System.out.flush();
        }
    catch(Exception e) { e.printStackTrace(); }

    }
    
}




