import java.awt.Graphics;
import java.awt.Color;
import java.sql.*;
import java.util.Vector;
import twz1.jdbc.mysql.jdbcMysqlBase;

public class jdbcTestApplet1 extends java.applet.Applet
       implements Runnable
{
int jstep;
Thread sThread;
Vector mm;

public void init()
    {
    jstep = 0;
    sThread = null;
    mm = new Vector();
    }

public void start()
    {
    if(sThread == null)
        {
        sThread = new Thread(this);
        sThread.start();
        }
    }


public void stop()
    {
    if(sThread != null) sThread.stop();
    sThread = null;
    }
   

public void run()
    {

    setBackground(Color.white);
    outmessage("starting ...");
    //-------------------------------------------------------------

    try {
        Class.forName("twz1.jdbc.mysql.jdbcMysqlDriver");
        }
    catch(Exception e){errmessage(e);}
    outmessage("Driver loaded!");

    String ss;
    String t[] = jdbcMysqlBase.getDefaultNames();
    for(int i = 0; i < t.length; i++)
        {
        ss = new String(t[i] + "  " + 
               jdbcMysqlBase.getDefault(t[i]));
        outmessage(ss);
        }

    //-------------------------------------------------------------

    Connection cx = null;
    String url = "jdbc:z1MySQL://localhost/stuff?user=zellert";
    int xrc = 0;
    boolean brc = false;
    try {
        cx = DriverManager.getConnection(url);
        }
    catch(Exception se){errmessage(se);} 
    outmessage("Connected!");
  
   //------------------------------------------------------------
  
    try {
        cx.setCatalog("jdbctest");
        String s = cx.getCatalog();
        System.out.println("Catalog is now " + s);
        }
    catch(Exception e) { errmessage(e); }
    outmessage("Catalog set!");

    //------------------------------------------------------------ 

    Statement st = null;

    try {
        st = cx.createStatement();
        }
    catch(Exception e) { errmessage(e); }
    outmessage("statement created!");

    //------------------------------------------------------------

    try {
        xrc = st.executeUpdate( "create table books (rownum int not null"
                              +   " auto_increment, bname text not null,"
                              +   " author text not null, pubdate int,"
                              +   " isbn char(20) not null, price decimal(6,2),"
                              +   " primary key(isbn), index(rownum))" ); 
        }
    catch(Exception e) { errmessage(e); }
    outmessage("table created! " + String.valueOf(xrc));
    //------------------------------------------------------------

    try {
       st.executeUpdate( "insert into books values(0, 'Essential System Administration', 'Frisch', 1993, '0-937175-80-3', 29.95)");
        st.executeUpdate( "insert into books values(0, 'C, the Complete Reference',  'Schildt', 1987, '0-07-881263-1', 24.95)");
        st.executeUpdate( "insert into books values(0, 'Teach Yourself C++',  'Stevens', 1993, '1-55828-250-5', 29.95)");
        st.executeUpdate( "insert into books values(0, 'Operating Systems, Design and Implementation',  'Tanenbaum', 1987, '0-13-637406-9', 59.95)");
        }
    catch(Exception e) { errmessage(e); }
    outmessage("table loaded");

    //-----------------------------------------------------------------

    try {
        brc = st.execute("select * from books");
        ResultSet rs = st.getResultSet();
        String a, b, c, d, e, f, s;
        while(rs.next())
            {
            a = rs.getString(1);
            b = rs.getString(2);
            c = rs.getString(3);
            d = rs.getString(4);
            e = rs.getString(5);
            f = rs.getString(6);
            s = new String(a + " - " + b + " - " + c + " - " 
                               + d + " - " + e + " - " + f);
            outmessage(s);
            }
        rs.close();
        }
    catch(Exception e) { errmessage(e); }

    //-----------------------------------------------------------------

    try {
        st.execute( "drop table books");
        st.getUpdateCount();
        }
    catch(Exception e) { errmessage(e); }
    outmessage("table deleted!");

    //---------------------------------------------------------------
    
    try { st.close(); }
    catch(Exception e) { errmessage(e); } 

    //---------------------------------------------------------------

    try { cx.close(); }
    catch(Exception se){errmessage(se);}
      
    }

void outmessage(String s)
    {
    mm.addElement(s);
    repaint();
    try {sThread.sleep(1000); } catch(InterruptedException ie){}
    }

void errmessage(Exception e)
   {
   mm.addElement("Error  " + e.getMessage());
   repaint();
   try { for(;;)sThread.sleep(30000); }
   catch(InterruptedException ee) {}
   }

public void paint(Graphics g)
    {
    int i, x, y;
    x =  y = 10;
    String message;

    for(i = 0 ; i < mm.size(); i++, y+= 15)
        {
        message = (String) mm.elementAt(i);
        g.drawString(message, x, y);
        }
    }
}



