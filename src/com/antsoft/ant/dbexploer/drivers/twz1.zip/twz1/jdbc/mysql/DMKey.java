/**
*** Program DMKey.java     
***    in product twz1jdbcForMysql, 
***    Copyright 1998 by Terrence W. Zellers.
***   
***  All rights explicitly reserved.
***
***  See file "LICENSE" in this package for conditions of use.
**/


package twz1.jdbc.mysql;
import java.sql.*;
import java.util.Hashtable;
import java.util.Vector;


final class DMKey
{
String keyName;
byte[] bKeyName;
boolean unique;
boolean autoinc;
Vector tines;

DMKey(ResultSet rs) throws SQLException
    {
    try {
        String test;
        bKeyName = rs.getBytes(3);
        keyName = new String(bKeyName);
        test = rs.getString(2);
        if(test.equals("1")) unique = false; else unique = true;
        tines = new Vector();
        autoinc = false;
        }
    catch(Exception e)
        {
        String em = e.getMessage();
        if(em == null) em = e.toString();
        String o = "\nE2400 Error in DBMDkey() constructor " + em;
        jdbcMysqlBase.errMessage(o);
        }
    }

}
   



