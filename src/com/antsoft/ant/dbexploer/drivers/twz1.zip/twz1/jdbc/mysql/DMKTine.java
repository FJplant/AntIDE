/**
*** Program DMKTine.java     
***    in product twz1jdbcForMysql, 
***    Copyright  1998 by Terrence W. Zellers.
***   
***  All rights explicitly reserved.
***
***  See file "LICENSE" in this package for conditions of use.
**/

package twz1.jdbc.mysql;
import java.sql.*;

final class DMKTine
{
DMTabCol column;
int seq;
String order;
byte[] cardinality;

DMKTine(ResultSet rs, DMTable table) 
        throws SQLException
    {
    try {
        String test;
        seq = rs.getInt(4);
        order = rs.getString(6);
        test = rs.getString(5);
        column = (DMTabCol) table.table.get(test);
        if(column == null) 
                jdbcMysqlBase.errMessage("\nE2501 no column " + test);
        test = rs.getString(7);
        if(test == null) cardinality = "0".getBytes();
        else cardinality = test.getBytes();
        }
    catch(Exception e)
        {
        String em = e.getMessage();
        if(em == null) em = e.toString();
        String o = "\nE2500 Error in DBMDkeyTine() constructor " + em;
        jdbcMysqlBase.errMessage(o);
        }
    }
}

