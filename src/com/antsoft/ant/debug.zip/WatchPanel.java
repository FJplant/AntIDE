/*
 * Ant ( JDK wrapper Java IDE )
 * Version 1.0
 * Copyright (c) 1998-1999 Antsoft Co. All rights reserved.
 *  This program and source file is protected by Korea and international
 * Copyright laws.
 *
 * Author:       Kwon, Young Mo
 * $Header: $
 * $Revision: $
 * $History: $
 */

package com.antsoft.ant.debugger;

import java.awt.*;
import java.util.Vector;
import javax.swing.*;

public class WatchPanel extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JList locals = new JList();
  public WatchPanel() {
    try  {
      uiInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void uiInit() throws Exception {
    this.setLayout(borderLayout1);
    add(new JLabel("Watch List"), BorderLayout.NORTH);
    add(new JScrollPane(locals), BorderLayout.CENTER);
    setPreferredSize( new Dimension( 300, 200 ) );
  }

  public void setLocals( Vector list ) {
    locals.setListData( list );
  }
}

