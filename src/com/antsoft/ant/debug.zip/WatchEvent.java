/*
 * Ant ( JDK wrapper Java IDE )
 * Version 1.0
 * Copyright (c) 1998-1999 Antsoft Co. All rights reserved.
 *  This program and source file is protected by Korea and international
 * Copyright laws.
 *
 * Author:       Kwon, Young Mo
 * $Header: /AntIDE/source/ant/debugger/WatchEvent.java 2     99-05-16 11:42p Multipia $
 * $Revision: 2 $
 * $History: WatchEvent.java $
 * 
 * *****************  Version 2  *****************
 * User: Multipia     Date: 99-05-16   Time: 11:42p
 * Updated in $/AntIDE/source/ant/debugger
 * 
 * *****************  Version 1  *****************
 * User: Multipia     Date: 99-05-11   Time: 6:48p
 * Created in $/AntIDE/source/ant/debugger
 * Initial Version.
 */

package  com.antsoft.ant.debugger;

import java.util.EventObject;

// This defines a new event, with minimum state.
/**
 * Break Point�� ����, ������ ���� ����� �ϰ�,
 * Break Point�� �ɷ��� ���� �߻��Ѵ�.
 */
public class WatchEvent extends EventObject {
  static final int WATCH_ADDED=1;
  static final int WATCH_REMOVED=2;
  private int id=0;
  private WatchCallback callback;

  // Used when member is true;
  private String clazz;
  private String name;

  // used when member is false;

  public int getID() {return id;};

  WatchEvent(Object source,int i, WatchCallback callback) {
    super(source);
    this.callback = callback;
    id=i;
  }

  WatchEvent(Object source, int i, WatchCallback callback, String name) {
    this(source, i, callback);
    this.name = name;
  }

  WatchEvent(Object source, int i, WatchCallback callback, String name, String clazz) {
    this(source, i, callback, name);
    this.clazz = clazz;
  }

  public String getClazz() {
    return clazz;
  }

  public String getname() {
    return name;
  }
  public WatchCallback getWatchCallback() {
    return callback;
  }
}

