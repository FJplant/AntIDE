/*
 * Ant ( JDK wrapper Java IDE )
 * Version 1.0
 * Copyright (c) 1998-1999 Antsoft Co. All rights reserved.
 *  This program and source file is protected by Korea and international
 * Copyright laws.
 *
 * Author:       Kwon, Young Mo
 * $Header: /AntIDE/source/ant/debugger/WatchManager.java 2     99-05-16 11:42p Multipia $
 * $Revision: 2 $
 * $History: WatchManager.java $
 * 
 * *****************  Version 2  *****************
 * User: Multipia     Date: 99-05-16   Time: 11:42p
 * Updated in $/AntIDE/source/ant/debugger
 * 
 * *****************  Version 1  *****************
 * User: Multipia     Date: 99-05-11   Time: 6:48p
 * Created in $/AntIDE/source/ant/debugger
 * Initial Version.
 */

package  com.antsoft.ant.debugger;

import java.util.Vector;

// This is an example of a non-visual Bean that fires the new events
public class WatchManager {
  public WatchManager() {
  }

  // The add/remove methods provide the signature for the IDE to recognize
  // these events and show them in the event list
  public synchronized void addWatchEventListener(WatchEventListener l) {
    listenerList.addElement(l);
  }
  public synchronized void removeWatchEventListener(WatchEventListener l){
    listenerList.removeElement(l);
  }

  // A single process method keeps all event dispatching in one place.
  // Separate processEVENT1, processEVENT2, etc methods could also be used.
  protected void processWatchEvent(WatchEvent e) {
    switch (e.getID()) {
      case WatchEvent.WATCH_ADDED:
        for (int i=0; i<listenerList.size(); i++)
          //Send event to all registered listeners
          ((WatchEventListener)listenerList.elementAt(i)).watchAdded(e);
        break;
      case BreakpointEvent.BREAKPOINT_REMOVED:
        for (int i=0; i<listenerList.size(); i++)
          ((WatchEventListener)listenerList.elementAt(i)).watchRemoved(e);
        break;
    }
  }

  // A test method to fire all 3 example events
  public void testWatchEvent () {
    processWatchEvent (new WatchEvent(this, WatchEvent.WATCH_ADDED, null));
    processWatchEvent (new WatchEvent(this, WatchEvent.WATCH_REMOVED, null));
  }

  private Vector listenerList = new Vector();
}
