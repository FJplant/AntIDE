/*
 * Ant ( JDK wrapper Java IDE )
 * Version 1.0
 * Copyright (c) 1998-1999 Antsoft Co. All rights reserved.
 *  This program and source file is protected by Korea and international
 * Copyright laws.
 *
 * Author:       Kwon, Young Mo
 * $Header: /AntIDE/source/ant/debugger/SourcePanel.java 3     99-05-16 11:42p Multipia $
 * $Revision: 3 $
 * $History: SourcePanel.java $
 *
 * *****************  Version 3  *****************
 * User: Multipia     Date: 99-05-16   Time: 11:42p
 * Updated in $/AntIDE/source/ant/debugger
 *
 * *****************  Version 2  *****************
 * User: Multipia     Date: 99-05-11   Time: 8:33p
 * Updated in $/AntIDE/source/ant/debugger
 * ���� �����θ� ����
 */

package com.antsoft.ant.debugger;

import java.awt.*;
import java.io.*;
import java.util.Vector;
import javax.swing.*;

import sun.tools.debug.*;

public class SourcePanel extends JPanel {
  private DebuggerProxy debuggerProxy;
  BorderLayout borderLayout1 = new BorderLayout();
  JList sourceList = new JList();
  DefaultListModel sourceModel = new DefaultListModel();

  public SourcePanel( DebuggerProxy proxy ) {
    debuggerProxy = proxy;
    try  {
      uiInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void uiInit() throws Exception {
    this.setLayout(borderLayout1);
    sourceList.setModel(sourceModel);
    add(new JLabel("Source View"), BorderLayout.NORTH);
    add(new JScrollPane(sourceList), BorderLayout.CENTER);
    setPreferredSize( new Dimension( 300, 200 ) );
  }

  public void showLine( int line ) {
    sourceList.setSelectedIndex( line );
  }

  public void setClass( String classId ) {
    //System.out.println("SourcePanel : setClass start");
    sourceModel.removeAllElements();

    RemoteStackFrame frame = null;
    if (debuggerProxy.getCurrentThread() == null) {
        sourceModel.addElement("No thread specified.");
        return;
    }

    try {
        frame = debuggerProxy.getCurrentThread().getCurrentFrame();
    } catch (IllegalAccessError e) {
        sourceModel.addElement("Current thread isn't suspended.");
        return;
    } catch (ArrayIndexOutOfBoundsException e) {
        sourceModel.addElement("Thread is not running (no stack).");
        return;
    } catch (Exception e) {
        System.err.println( e.toString() );
    }

    if (frame.getPC() == -1) {
        sourceModel.addElement("Current method is native");
        return;
    }

    int lineno;
    lineno = frame.getLineNumber();
    int startLine = (lineno > 4) ? lineno - 4 : 1;
    int endLine = startLine + 9;

    InputStream rawSourceFile = null;
    DataInputStream sourceFile = null;
    try {
      rawSourceFile = frame.getRemoteClass().getSourceFile();
      if (rawSourceFile == null) {
        sourceModel.addElement("Unable to find " +
                          frame.getRemoteClass().getSourceFileName());
        return;
      }
      sourceFile = new DataInputStream(rawSourceFile);
    } catch ( Exception e ) {
    }

    String sourceLine = null;

    /* Skip through file to desired window. */
/*
    for (int i = 1; i <= startLine; i++) {
        sourceLine = sourceFile.readLine();
    }
    if (sourceLine == null) {
        source.addElement(new Integer(lineno).toString() +
                          " is an invalid line number for the file " +
                          frame.getRemoteClass().getSourceFileName());
    }
*/
    /* Print lines */
    try {
      sourceLine = sourceFile.readLine();
      System.out.println("[SourcePanel] firstLine : " + sourceLine);
      sourceModel.addElement(sourceLine);
      while ( sourceLine != null ) {
        sourceModel.addElement(sourceLine);
        sourceLine = sourceFile.readLine();
        //System.out.println(sourceLine);
      }
    } catch ( IOException e ) {
    }
  }
}

