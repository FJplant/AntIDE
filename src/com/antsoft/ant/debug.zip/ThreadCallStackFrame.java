/*
 * Ant ( JDK wrapper Java IDE )
 * Version 1.0
 * Copyright (c) 1998-1999 Antsoft Co. All rights reserved.
 *  This program and source file is protected by Korea and international
 * Copyright laws.
 *
 * Author:       Kwon, Young Mo
 * $Header: /AntIDE/source/ant/debugger/ThreadsPanel.java 2     99-05-16 11:42p Multipia $
 * $Revision: 2 $
 * $History: ThreadsPanel.java $
 * 
 * *****************  Version 2  *****************
 * User: Multipia     Date: 99-05-16   Time: 11:42p
 * Updated in $/AntIDE/source/ant/debugger
 * 
 * *****************  Version 1  *****************
 * User: Multipia     Date: 99-05-11   Time: 6:48p
 * Created in $/AntIDE/source/ant/debugger
 * Initial Version.
 */

package com.antsoft.ant.debugger;

import java.awt.*;
import java.util.Vector;
import javax.swing.*;

public class ThreadCallStackFrame extends JFrame {
  BorderLayout borderLayout1 = new BorderLayout();
  private CallStackPanel callStackPanel;
  private ThreadsPanel threadPanel;

  JList threads = new JList();
  public ThreadCallStackFrame() {
    super("Thread & Call Stack View");
    try  {
      threadPanel = new ThreadsPanel();
      callStackPanel = new CallStackPanel();
      uiInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void uiInit() throws Exception {
    getContentPane().setLayout(borderLayout1);
    // ThreadPanel�� CallStackPanel ���̿� SplitPane����
    JSplitPane sp = new JSplitPane( JSplitPane.VERTICAL_SPLIT, threadPanel, callStackPanel );
    sp.setDividerSize(4);
    sp.setOneTouchExpandable(true);
    
    getContentPane().add(sp, BorderLayout.CENTER);
    pack();
    setVisible(true);
  }

  public ThreadsPanel getThreadsPanel() {
    return threadPanel;
  }

  public CallStackPanel getCallStackPanel() {
    return callStackPanel;
  }
}

