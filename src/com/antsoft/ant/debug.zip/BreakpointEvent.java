/*
 * Ant ( JDK wrapper Java IDE )
 * Version 1.0
 * Copyright (c) 1998-1999 Antsoft Co. All rights reserved.
 *  This program and source file is protected by Korea and international
 * Copyright laws.
 *
 * Author:       Kwon, Young Mo
 * $Header: /AntIDE/source/ant/debugger/BreakpointEvent.java 2     99-05-16 11:42p Multipia $
 * $Revision: 2 $
 * $History: BreakpointEvent.java $
 * 
 * *****************  Version 2  *****************
 * User: Multipia     Date: 99-05-16   Time: 11:42p
 * Updated in $/AntIDE/source/ant/debugger
 * 
 * *****************  Version 1  *****************
 * User: Multipia     Date: 99-05-11   Time: 6:48p
 * Created in $/AntIDE/source/ant/debugger
 * Initial Version.
 */

package  com.antsoft.ant.debugger;

import java.util.EventObject;

// This defines a new event, with minimum state.
/**
 * Break Point�� ����, ������ ���� ����� �ϰ�,
 * Break Point�� �ɷ��� ���� �߻��Ѵ�.
 */
public class BreakpointEvent extends EventObject {
  static final int BREAKPOINT_ADDED=1;
  static final int BREAKPOINT_REMOVED=2;
  private int id=0;
  private boolean stopAt;
  private BreakpointCallback callback;

  // Used when stopAt is false;
  private String clazz;
  private String method;
  private String args;

  // used when stopAt is true;
  private String filename;
  private int line;

  public int getID() {return id;};

  BreakpointEvent(Object source,int i, BreakpointCallback callback) {
    super(source);
    this.callback = callback;
    id=i;
  }

  BreakpointEvent(Object source, int i, BreakpointCallback callback, String clazz, String method) {
    this(source, i, callback);
    stopAt = false;

    this.clazz = clazz;
    this.method = method;
  }

  BreakpointEvent(Object source, int i, BreakpointCallback callback, String clazz, String method, String args) {
    this(source, i, callback, clazz, method);
    this.args = args;
  }

  BreakpointEvent(Object source, int i, BreakpointCallback callback, String filename, int line) {
    this(source, i, callback);
    stopAt = true;

    this.filename = filename;
    this.line = line;
  }

  public boolean isStopAt() {
    return stopAt;
  }

  public String getClazz() {
    return clazz;
  }

  public String getMethod() {
    return method;
  }

  public String getArgs() {
    return args;
  }

  public String getFilename() {
    return filename;
  }

  public int getLine() {
    return line;
  }

  public BreakpointCallback getBreakpointCallback() {
    return callback;
  }
}

