package com.antsoft.ant.debugger;

class LoadedClassTreeNode extends javax.swing.tree {
}

